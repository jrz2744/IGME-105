﻿using System;
using System.Reflection.Metadata;

/*
 * Program: Program.cs
 * Author: Jake Zoltun
 * Email: jrz2744@rit.edu
 * Purpose: PE5
 * Git Link: N/A
 * Date: 2/6/2023
 * Modifications: Finished PE5
 */


namespace PE5zoltun
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Variable which temp hold values
            string mathSolution;

            // Intro to ints
            Console.WriteLine("Integer Segment:");
            
            // Sin 30
            mathSolution = (Math.Round(Math.Sin(30 * Math.PI / 180), 2)).ToString();
            Console.WriteLine("Sin of 30°: {0}", mathSolution);

            // Cos 60
            mathSolution = (Math.Round(Math.Cos(60 * Math.PI / 180), 2)).ToString();
            Console.WriteLine("Cos of 60°: {0}", mathSolution);

            // 7^6
            mathSolution = Math.Pow(7, 6).ToString();
            Console.WriteLine("7 to the 6th Power: {0}", mathSolution);

            // Max of 4 int
            int[] integerArray = new int[4] { 1, 2, 3, 4};
            mathSolution = integerArray.Max().ToString();
            Console.WriteLine("Max of [1, 2, 3, 4]: {0}", mathSolution);

            // 2548.454821 floored
            mathSolution = Math.Floor(2548.454821).ToString();
            Console.WriteLine("Integer Part of 2548.454821: {0}", mathSolution);

            // 78.651 Rounded
            mathSolution = Math.Round(78.681).ToString();
            Console.WriteLine("78.651 Rounded: {0}", mathSolution);

            // Intro to Strings
            int indexSolution;
            Console.WriteLine("\nString Segment:");

            // User input
            Console.Write("The user interface designers of Windows 11 should learn how to: ");
            string stringSolution = Console.ReadLine();
            
            // User failsafe
            while (stringSolution == null)
            {
                Console.Write("\nPlease enter a valid input: ");
                stringSolution = Console.ReadLine();
            }

            // Index of z
            indexSolution = stringSolution.IndexOf("z");
            if (indexSolution == -1)
            {
                Console.WriteLine("There is a z at index {0}.\nThis means there is no z in the word.", indexSolution);
            }
            else
            {
                Console.WriteLine("There is an z at index {0}.\nThis means that the letter {1} characters in is a z.", indexSolution, indexSolution + 1);
            }

            // Index of s
            indexSolution = stringSolution.IndexOf("s");
            if (indexSolution == -1)
            {
                Console.WriteLine("There is an s at index {0}.\nThis means there is no s in the word.", indexSolution);
            }
            else
            {
                Console.WriteLine("There is an s at index {0}.\nThis means that the letter {1} characters in is an s.", indexSolution, indexSolution + 1);
            }

            // 4th letter in string
            if (stringSolution.Length >= 4)
            {
                Console.WriteLine("The 4th character in your word is {0}.", stringSolution[3]);
            }
            else
            {
                Console.WriteLine("Unable to find 4th character in your word because it is too short.");
            }

            // Length of string
            Console.WriteLine("Total length of your string: {0}", stringSolution.Length);

            // ToLower then ToUpper
            Console.WriteLine("Your string in lowercase: {0}\nYour string in uppercase: {1}", stringSolution.ToLower(), stringSolution.ToUpper());

            // Intro to String Formatting
            Console.WriteLine("\nString Formatting Segment:");

            // Tax rate
            const double taxRate = 5.25;
            Console.WriteLine("Tax rate: {0}%", taxRate);

            // Get user input
            Console.Write("How much will you spend on pizza: ");
            string pizzaString = Console.ReadLine();
            
            // Convert pizzaString to double
            double pizzaMoney;
            double.TryParse(pizzaString, out pizzaMoney);

            // Check for integer
            while (pizzaMoney <= 0)
            {
                Console.Write("Please enter a valid integer amount: ");
                pizzaString = Console.ReadLine();
                double.TryParse(pizzaString, out pizzaMoney);
            }

            // Add 0.12 to pizza money
            Console.WriteLine("\nAdding $0.12...");
            pizzaMoney += 0.12;

            // Add tax rate
            Console.WriteLine("Adding tax...");
            pizzaMoney += (pizzaMoney * taxRate / 100);

            // Output total
            Console.WriteLine("Total cost for pizza: {0}", pizzaMoney.ToString("C"));
        }
    }
}