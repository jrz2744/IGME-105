﻿using System;

/* Program: PE3.cs
 * Author: Jake Zoltun 
 * Email: jrz2744@rit.edu 
 * Purpose: Intro to Trouble Game 
 * Git Link: https://kgcoe-git.rit.edu/jrz2744/PE-jrz2744/-/tree/main/PE3_jrz2744 
 * Date: 2/1/2023 
 * Modifications: Created this header which was missing. oops :P                
 *                Added comments to some functions and created start of game methods and functions 
 */

namespace PE3_jrz2744
{
    internal class Program
    {
        /// <summary>
        /// Global AI player varaibles
        /// </summary>
        const string AI_NAME = "RoboTrouble";
        const string AI_COLOR = "G";

        /// <summary>
        /// Prints info on the player and AI player. Color chosen and current position.
        /// </summary
        static public void PrintInfo(string playerName, string playerColor)
        {
            Console.WriteLine("--------------------------------------------------------------\n" +
                              "| Player Name: " + playerName + "\t\tPiece Color: " + playerColor + "\tPlayer Position: 0 |\n" +
                              "| AI Name: " + AI_NAME + "\t\tPiece Color: " + AI_COLOR + "\tAI Position: 14 |\n" +
                              "--------------------------------------------------------------");
        }
        /// <summary>
        /// Prints current date and time
        /// </summary>
        static public void PrintTime()
        {
            Console.WriteLine("Current Date & Time is: " + DateTime.Now.ToString("MM/dd/yyyy h:mm:ss tt"));
        }

        static void Main(string[] args)
        {
            Console.Write("To play, we need to know your name: ");
            string playerName = Console.ReadLine();
            Console.Write("\nThank you, " + playerName + ". Please pick a color to play (B)lue, (R)ed, (Y)ellow: ");
            string playerColor = Console.ReadLine().ToUpper();
            Boolean validColor = false;
            /// Checks if player has entered a valid color, if not it re-prompts the user for a valid color
            while (!validColor)
            {
                switch (playerColor.ToUpper())
                {
                    case "B":
                        validColor = true;
                        break;
                    case "R":
                        validColor = true;
                        break;
                    case "Y":
                        validColor = true;
                        break;
                    default:
                        Console.Write("\nPlease enter a valid color (B, R, Y): ");
                        playerColor = Console.ReadLine();
                        continue;
                }
            }
            /// Sorry for this block of text but its not that important
            Console.WriteLine("\n\n\t\t\tWelcome " + playerName + " to Pop-O-Matic Trouble\n\n" +
                              "Rules:\n" +
                              " =====================\n" +
                              "Trouble is easy to play. Players will take turn to roll a die.\n" +
                              "Roll a to start a piece on the board...Get all 4 pieces around before\n" +
                              "any other player. Land on another player piece and send them back to the start.\n\n" +
                              "\t\t\tGood Luck!");
            PrintInfo(playerName, playerColor);
            PrintTime();
        }
    }
}