﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data.Common;

/* Program: PE3/Program.cs
 * Author: Jake Zoltun 
 * Email: jrz2744@rit.edu 
 * Purpose: Intro to Trouble Game 
 * Git Link: https://kgcoe-git.rit.edu/jrz2744/PE-jrz2744/-/tree/main/PE3
 * Date: 2/3/2023 
 * Modifications: Finished all aspects of PE3 and some more :)
 *                Moved to back from temp file (Testing directory) becuase of a version mismatch in visual studio libs, not sure how to fix it currently
 *                Added lots of failsafes to welcome sequence
 *                Added player and AI creation
 *                Added call to PrintTime function and PrintInfo function at current EOF
 *                May have written a bit much for PE3 submission but I was enjoying the coding :P
 */


namespace PE3
{
    /// <summary>
    /// Class to store most helper functions for the main game
    /// </summary>
    public class Utility
    {
        /// <summary>
        /// Prints a visual reresentation of the game board to the players
        /// </summary>
        /// <param name="players"> Array of all players in the current game </param>
        public static void PrintBoard(Player[] players)
        {
            // Create function for printing game board
            // GAME BOARD CURRENTLY DOES NOT EXIST
        }
        /// <summary>
        /// Prints player info: Player color, Spawn location, and Player name
        /// </summary>
        /// <param name="players"> Array of all players in the current game </param>
        public static void PrintInfo(Player[] players)
        {
            Console.WriteLine(String.Format("\n{0}", new String('-', 69)));
            for (int i = 0; i < players.Length; i++)
            {
                // MAKE BETTER/STANDARDIZE FORMAT FOR THIS OUTPUT
                Console.WriteLine("| Player Name: {0} | Piece Color: {1} | Player Position: {2} |", players[i].name, players[i].color, players[i].spawn);
            }
            Console.WriteLine(String.Format("{0}", new String('-', 69)));
        }
        /// <summary>
        /// Prints current date and time
        /// </summary>
        static public void PrintTime()
        {
            Console.WriteLine("\nCurrent Date & Time is: " + DateTime.Now.ToString("MM/dd/yyyy h:mm:ss tt"));
        }
    }
    /// <summary>
    /// Stores all 4 colors of playable pawns for Trouble game
    /// </summary>
    public static class Colors
    {
        public const string RED = "Red";
        public const string GREEN = "Green";
        public const string BLUE = "Blue";
        public const string YELLOW = "Yellow";
    }

    /// <summary>
    /// Player class which stores information about each player
    /// </summary>
    public class Player
    {
        public bool isAI { get; set; }
        public string name { get; set; }
        public string color { get; set; }
        public int spawn { get; set; }
        /// <summary>
        /// Creation of player object
        /// </summary>
        /// <param name="isAI"> True if the player object is an AI player </param>
        /// <param name="name"> Player's name as a string </param>
        /// <param name="location"> Player's location as a string </param>
        public Player(int playerOrder, bool isAI, string name, string color, int spawn)
        {
            this.isAI = isAI;
            if (name == null)
            {
                this.name = String.Format("Player{0}", playerOrder);
            }
            else
            {
                this.name = name;
            }
            switch (color.ToUpper())
            {
                case "R":
                    this.color = Colors.RED;
                    break;
                case "G":
                    this.color = Colors.GREEN;
                    break;
                case "B":
                    this.color = Colors.BLUE;
                    break;
                case "Y":
                    this.color = Colors.YELLOW;
                    break;
                default:
                    Console.WriteLine("THIS SHOULD NEVER BE PRINTED! PLAYER CLASS COLOR ASSIGNMENT.");
                    break;
            }
            this.spawn = spawn;
        }
        public override string ToString()
        {
            return this.name;
        }
    }
    /// <summary>
    /// Runs all the game functions neatly
    /// </summary>
    internal class Program
    {
        const int MAX_PLAYERS = 4;
        static void Main(string[] args)
        {
            // INITIAL WELCOM TO TROUBLE GAME
            // SHOULD NEVER REPEAT
            // Use to center text: ("{0," + ((Console.WindowWidth / 2) + (TEXTHERE.Length / 2)) + "}", TEXTHERE));
            Console.Write(
                "Welcome to Pop-O-Matic Trouble!\n" +
                "===============================\n\n" +
                "Rules:\n" +
                "======\n" +
                "Trouble is easy to play. Players will take turns rolling a die.\n" +
                "Roll a 6 to start a piece on the board and get all 4 peices around the board before\n" +
                "any other player. Land on another player peice to send them back to the start!\n\n" +
                "Good Luck! Have Fun!\n\n" +
                "Press enter to continue...");
            Console.ReadLine();

            // GET TOTAL NUMBER OF REAL PLAYERS
            int numPlayers = -1;
            string numPlayersInput = "";
            Console.Write("\nHow many Players will there be in this game? (1-4) ");
            while (numPlayers == -1)
            {
                numPlayersInput = Console.ReadLine();
                switch (numPlayersInput)
                {
                    case "1":
                        numPlayers = 1;
                        break;
                    case "2":
                        numPlayers = 2;
                        break;
                    case "3":
                        numPlayers = 3;
                        break;
                    case "4":
                        numPlayers = 4;
                        break;
                    default:
                        Console.Write("Please enter a valid number of players. (1-4) ");
                        break;
                }
            }

            // GET HOW MANY PLAYERS ARE AI
            int minAI = 0;
            if (numPlayers == 1)
            {
                minAI = 1;
            }
            int numAI = -1;
            if (numPlayers != 4)
            {
                string numAIInput = "";
                Console.Write("\nHow many AI players will there be? ({0}-{1}) ", minAI, (MAX_PLAYERS - numPlayers));
                while (numAI == -1)
                {
                    numAIInput = Console.ReadLine();
                    switch (numAIInput)
                    {
                        case "0":
                            numAI = 0;
                            break;
                        case "1":
                            numAI = 1;
                            break;
                        case "2":
                            numAI = 2;
                            break;
                        case "3":
                            numAI = 3;
                            break;
                        default:
                            Console.Write("Please enter a valid number of AI players. (0-{0}) ", (MAX_PLAYERS - numPlayers));
                            break;
                    }
                    if (numAI + numPlayers > 4)
                    {
                        numAI = -1;
                        Console.Write("Too many AI players. Please enter a valid number of AI players. (0-{0}) ", (MAX_PLAYERS - numPlayers));
                    }
                }
            }
            else
            {
                numAI = 0;
            }

            // PLAYER CREATION AND COLOR SELECTION
            // availableColors: Keeps track of all colors currently not in use by the players
            string[] availableColors = new string[] { "R", "G", "B", "Y" };
            Player[] players = new Player[numPlayers + numAI];
            string playerName = "UNIDENTIFIED_PLAYER_NAME";
            string playerColor = "UNIDENTIFIED_PLAYER_COLOR";
            //
            // CREATE A FUNCTION FOR PLAYER SPAWNS
            //
            int playerSpawn = 0;
            for (int i = 0; i < numPlayers; i++)
            {
                Console.Write("\nPlease enter the name for Player{0}: ", i + 1);
                playerName = Console.ReadLine();
                Console.Write("Please pick a color to play as ({0}): ", String.Join(",", availableColors));
                while (players[i] == null)
                {
                    playerColor = Console.ReadLine();
                    switch (playerColor.ToUpper())
                    {
                        case "R":
                            if (availableColors.Contains(playerColor.ToUpper()))
                            {
                                players[i] = new Player(i + 1, false, playerName, playerColor, playerSpawn);
                                List<string> tempColors = new List<string>(availableColors);
                                tempColors.Remove(playerColor.ToUpper());
                                availableColors = tempColors.ToArray();
                            }
                            else
                            {
                                Console.Write("That color has already been chosen. Please enter a valid color ({0}): ", String.Join(",", availableColors));
                            }
                            break;
                        case "G":
                            if (availableColors.Contains(playerColor.ToUpper()))
                            {
                                players[i] = new Player(i + 1, false, playerName, playerColor, playerSpawn);
                                List<string> tempColors = new List<string>(availableColors);
                                tempColors.Remove(playerColor.ToUpper());
                                availableColors = tempColors.ToArray();
                            }
                            else
                            {
                                Console.Write("That color has already been chosen. Please enter a valid color ({0}): ", String.Join(",", availableColors));
                            }
                            break;
                        case "B":
                            if (availableColors.Contains(playerColor.ToUpper()))
                            {
                                players[i] = new Player(i + 1, false, playerName, playerColor, playerSpawn);
                                List<string> tempColors = new List<string>(availableColors);
                                tempColors.Remove(playerColor.ToUpper());
                                availableColors = tempColors.ToArray();
                            }
                            else
                            {
                                Console.Write("That color has already been chosen. Please enter a valid color ({0}): ", String.Join(",", availableColors));
                            }
                            break;
                        case "Y":
                            if (availableColors.Contains(playerColor.ToUpper()))
                            {
                                players[i] = new Player(i + 1, false, playerName, playerColor, playerSpawn);
                                List<string> tempColors = new List<string>(availableColors);
                                tempColors.Remove(playerColor.ToUpper());
                                availableColors = tempColors.ToArray();
                            }
                            else
                            {
                                Console.Write("That color has already been chosen. Please enter a valid color ({0}): ", String.Join(",", availableColors));
                            }
                            break;
                        default:
                            Console.Write("Please enter a valid color ({0}): ", String.Join(",", availableColors));
                            break;
                    }
                }
            }

            // AI PLAYER CREATION
            Random rng = new Random();
            string[] AINames = { "Bot Linda", "Bot Karen", "Bot Greg", "Bot Jill", "Bot Henry", "Bot Tom", "Bot Sandy", "Bot Frank", "Bot Bill", "Bot Emily", "Bot Steven", "Bot Ashley" };
            string aiName = "UNIDENTIFIED_AI_NAME";
            string aiColor = "UNIDENTIFIED_AI_COLOR";
            int aiSpawn = 0;
            for (int i = 0; i < numAI; i++)
            {
                // THIS MAY PRODUCE OUT OF INDEX ERROR NEED TO FURTHER TEST RANDOM FUNCTIONS
                aiName = AINames[(int)rng.Next(0, 10)];
                aiColor = availableColors[rng.Next(0, availableColors.Length)];
                players[i + numPlayers] = new Player(-1, true, aiName, aiColor, aiSpawn);
                List<string> tempNames = new List<string>(AINames);
                tempNames.Remove(aiName);
                AINames = tempNames.ToArray();
                List<string> tempColors = new List<string>(availableColors);
                tempColors.Remove(aiColor.ToUpper());
                availableColors = tempColors.ToArray();
            }

            // CURRENT EOF AND TESTING
            Utility.PrintInfo(players);
            Utility.PrintTime();
            Console.WriteLine("This is the temp end to Trouble!");
        }
    }
}