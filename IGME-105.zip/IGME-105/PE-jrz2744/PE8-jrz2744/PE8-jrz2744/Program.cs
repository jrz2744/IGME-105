﻿using System;
using System.Data;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Xml.Schema;


/* Program: PE7-jrz2744/Program.cs
 * Author: Jake Zoltun 
 * Email: jrz2744@rit.edu 
 * Purpose: Practice Example 8
 * Git Link: https://kgcoe-git.rit.edu/jrz2744/PE-jrz2744/PE8-jrz2744
 * Date: 2/13/2023 
 * Modifications: 2/13/23 - Completed PE7 - jrz
 *                2/13/23 - Added function for player turn and made it a loop - jrz
 *                2/13/23 - Created function for giving players pawns - jrz
 *                2/13/23 - Created board and locations on board - jrz
 *                2/13/23 - Created Trouble Game mechanics - jrz
 *                2/15/23 - Tansfered file to PE8-jrz2744 - jrz
 *                2/15/23 - Added pawn distance variable to track when a pawn has done a lap - jrz
 *                2/17/23 - Added lots of checks for ValidMove - jrz
 *                2/17/23 - Move now checks for opposite color pawns and sends them to their home - jrz
 *                2/17/23 - Pawns can now move into goal - jrz
 *                2/17/23 - SAME COLOR PAWNS CAN LAND ON EACH OTHER AND OCCUPY THE SAME SPACE NEEDS FIXING - jrz
 *                2/17/23 - Pawns can no longer land on each other of the same color ^RESOLVED^ - jrz
 *                2/17/23 - Finished PE8 - jrz
 *                2/17/23 - NEED TO ADD AI PLAYER TURN AND THEN COMPLETE GAME WINNING LOOP
 */


namespace PE7_jrz2744
{
    /// <summary>
    /// Class to store most helper functions for the main game
    /// </summary>
    public class Utility
    {
        /// <summary>
        /// Creates a board for the players to play on
        /// </summary>
        /// <param name="players"> Current list of players </param>
        /// <returns> Board object to play game </returns>
        public static Board CreateBoard(Player[] players)
        {
            // CREATE THE BOARD
            return new Board(players);
        }
        /// <summary>
        /// Created all four pawns for each player
        /// </summary>
        /// <param name="players"></param>
        public static void CreatePawns(Player[] players)
        {
            foreach (Player player in players)
            {
                Pawn[] pawns = new Pawn[4];
                for (int i = 0; i < 4; i++)
                {
                    pawns[i] = new Pawn(player.spawn, player.color);
                }
                player.pawns = pawns;
            }
        }

        /// <summary>
        /// Prints player info: Player color, Spawn location, and Player name
        /// </summary>
        /// <param name="players"> Array of all players in the current game </param>
        public static void PrintInfo(Player[] players)
        {
            Console.WriteLine(string.Format("\n{0}", new string('-', 69)));
            for (int i = 0; i < players.Length; i++)
            {
                // MAKE BETTER/STANDARDIZE FORMAT FOR THIS OUTPUT
                Console.WriteLine("| Player Name: {0} | Piece Color: {1} | Player Position: {2} |", players[i].name, players[i].color, players[i].spawn);
            }
            Console.WriteLine(string.Format("{0}", new string('-', 69)));
        }
        /// <summary>
        /// Prints current date and time
        /// </summary>
        static public void PrintTime()
        {
            Console.WriteLine("\nCurrent Date & Time is: {0}", DateTime.Now.ToString("MM/dd/yyyy h:mm:ss tt"));
        }
        /// <summary>
        /// Changes the players order to reflect what they rolled on their first turn
        /// </summary>
        /// <param name="players"> List of all current players in the game </param>
        /// <param name="rng"> Current Random value for rng rolls </param>
        static public void firstRoll(Player[] players, Random rng)
        {
            Console.WriteLine("\nAll players rolling for first turn...");
            // Get player rolls
            int[] rollArray = new int[players.Length];
            int roll;
            for (int i = 0; i < players.Length; i++)
            {
                roll = rng.Next(1, 7);
                Console.WriteLine("{0} rolled a {1}!", players[i].name, roll);
                rollArray[i] = roll;
            }
            // Set player order
            int maxValue;
            int maxIndex;
            for (int i = 0; i < players.Length; i++)
            {
                // Gets max roll and puts order
                maxValue = rollArray.Max();
                maxIndex = rollArray.ToList().IndexOf(maxValue);
                players[maxIndex].order = i;
                // Removes roll from list
                rollArray[maxIndex] = -1;
                if (i == 0)
                {
                    Console.WriteLine("\n{0} will go first!", players[maxIndex]);
                }
            }
            // Prints player order to players
            Console.Write("\nOrder");
            for (int i = 0; i < players.Length; i++)
            {
                foreach (Player player in players)
                {
                    if (player.order == i)
                    {
                        Console.Write("-> {0}", player.name);
                    }
                }
            }
        }

        /// <summary>
        /// Runs a player's turn
        /// </summary>
        /// <param name="player"> Current player whos turn it is </param>
        /// <param name="rng"> Random value for roll </param>
        public static void playerTurn(Player player, Random rng, Board board)
        {
            // Which players turn and roll
            Console.Write("\n{0}'s Turn.\nPress Enter to Roll...", player.name);
            int roll = rng.Next(1, 7);

            // Player Turn
            if (!(player.isAI))
            {
                // Roll Dice
                Console.ReadLine();
                Console.Write("{0} rolled a {1}!", player.name, roll);
                // When rolling a 6 and pawn is currently in home and out
                if (roll == 6 && player.IsHome() && player.CanMove())
                {
                    bool validInput;
                    int input = -1;
                    do
                    {
                        Console.Write("\n1: Move Pawn\n2: Free Pawn From Home\n->");
                        int.TryParse(Console.ReadLine(), out input);
                        switch (input)
                        {
                            case 1:
                                // Move a pawn
                                player.MovePawn(roll, board); validInput = true;
                                break;
                            case 2:
                                // Free Pawn from home
                                player.FreePawn(); validInput = true;
                                break;
                            default:
                                // Invalid Imput
                                Console.WriteLine("Invalid Option. Please Try Again (1-2).");
                                validInput = false;
                                break;
                        }
                    } while (!validInput);
                }
                // When rolling a 6 and pawn is currently in home and none are out
                else if (roll == 6 && player.IsHome() && !(player.CanMove()))
                {
                    bool validInput;
                    int input = -1;
                    do
                    {
                        Console.Write("\n1: Free Pawn From Home\n->");
                        int.TryParse(Console.ReadLine(), out input);
                        switch (input)
                        {
                            case 1:
                                // Free Pawn from home
                                player.FreePawn(); validInput = true;
                                break;
                            default:
                                // Invalid Imput
                                Console.WriteLine("Invalid Option. Please Try Again (1).");
                                validInput = false;
                                break;
                        }
                    } while (!validInput);
                }
                // When rolling anything else
                else
                {
                    if (player.CanMove())
                    {
                        bool validInput;
                        int input = -1;
                        do
                        {
                            Console.Write("\n1: Move Pawn\n->");
                            int.TryParse(Console.ReadLine(), out input);
                            switch (input)
                            {
                                case 1:
                                    // Move a pawn
                                    player.MovePawn(roll, board); validInput = true;
                                    break;
                                default:
                                    // Invalid Imput
                                    Console.WriteLine("Invalid Option. Please Try Again (1).");
                                    validInput = false;
                                    break;
                            }
                        } while (!validInput);
                    }
                    else
                    {
                        Console.Write("\nYou Cannot Move Any Pawns!\nPress Enter To Continue...");
                        Console.ReadLine();
                    }
                }
                // Check for second roll
                if (roll == 6)
                {
                    playerTurn(player, rng, board);
                }
            }

            // AI Turn
            else
            {
                Console.WriteLine("\n{0} rolled a {1}!", player.name, roll);
            }
        }
    }
    /// <summary>
    /// Stores all 4 colors of playable pawns for Trouble game
    /// </summary>
    public static class Colors
    {
        public const string RED = "Red";
        public const string GREEN = "Green";
        public const string BLUE = "Blue";
        public const string YELLOW = "Yellow";
    }
    /// <summary>
    /// Stores all information about board and actions for board
    /// </summary>
    public class Board
    {
        public Player[] players { get; set; }
        public Pawn[] spaces { get; set; }

        public Board(Player[] players)
        {
            int spawnIncrement = 0;
            this.players = players;
            //Places players on different corners
            // 2 players
            if (players.Length <= 2)
            {
                foreach (Player player in players)
                {
                    player.spawn = spawnIncrement;
                    spawnIncrement += 14;
                }
            }
            // More than 2 players
            else
            {
                foreach (Player player in players)
                {
                    player.spawn = spawnIncrement;
                    spawnIncrement += 7;
                }
            }
            this.spaces = new Pawn[28] {new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), 
                new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), 
                new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), 
                new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), 
                new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), 
                new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), 
                new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), new Pawn(-1, "Empty"), 
                new Pawn(-1, "Empty"), };
        }
        /// <summary>
        /// Prints the board to the players
        /// </summary>
        /// <returns> Visual representation of the board as a string </returns>
        public override string ToString()
        {
            // Create function for printing game board
            return "NOT READY D:";
        }
    }

    /// <summary>
    /// Class to store piece information including color and location
    /// </summary>
    public class Pawn
    {
        public int location { get; set; }
        public string color { get; set; }
        public bool inHome { get; set; }
        public bool inGoal { get; set; }
        public int goal { get; set; }
        public int spawn { get; set; }
        // Total tiles crosses to check when pawn has done a lap
        // Lap complete at 26 moves aka next 4 spaces are goal spaces
        public int distance { get; set; }
        public Pawn(int location, string color)
        {
            this.spawn = location;
            this.location = -1;
            this.color = color;
            this.inHome = true;
            this.inGoal = false;
            this.distance = 0;
            switch (location)
            {
                case 0:
                    this.goal = 26; break;
                default:
                    this.goal = spawn - 2; break;
            }
        }

        // True if a pawn can move
        // THIS DOES NOT CHECK FOR SAME COLOR PAWNS -> USE pawn.CompareColor
        public bool CanMove(int roll, Board board)
        {
            int newIndex;
            if ((newIndex = this.location + roll) > 27)
            {
                newIndex -= 28;
            }
            else
            {
                newIndex = this.location + roll;
            }
            // Check if pawn is out of spawn and not in goal
            if (!(this.inHome) && !(this.inGoal))
            {
                // Checks if move goes past max distance and if a pawn of the same color is already in that space
                if (this.distance + roll <= 30 && !(board.spaces[newIndex].CompareColor(this))) 
                {
                    bool checkGoal = false;
                    switch (this.distance + roll)
                    {
                        case 27:
                            newIndex = 0; checkGoal = true; break;
                        case 28:
                            newIndex = 1; checkGoal = true; break;
                        case 29:
                            newIndex = 2; checkGoal = true; break;
                        case 30:
                            newIndex = 3; checkGoal = true; break;
                        default:
                            break;
                    }
                    // Checks if the player is in range of goal
                    if (checkGoal)
                    {
                        // Checks which player's pawn this is
                        foreach (Player player in board.players)
                        {
                            if (player.color.Equals(this.color))
                            {
                                // Checks if a player already has a pawn in that goal slot
                                if (player.goal[newIndex] == 0)
                                {
                                    this.inGoal = true; return true;
                                }
                            }
                        }
                    }
                    // Check for same color landing on each other
                    if (board.spaces[newIndex].CompareColor(this)) { return false; }
                    return true;
                }
            } 
            return false;
        }

        // True if both pawn are the same color
        public bool CompareColor(Pawn otherPawn)
        {
            if (String.IsNullOrEmpty(this.color)) { return false; }
            if (this.color.Equals(otherPawn.color)) { return true; }
            return false;
        }
    }

    /// <summary>
    /// Player class which stores information about each player
    /// </summary>
    public class Player
    {
        public bool isAI { get; set; }
        public string name { get; set; }
        public string color { get; set; }
        public int spawn { get; set; }
        public int order { get; set; }
        public Pawn[] pawns { get; set; }
        public int[] goal { get; set; }

        /// <summary>
        /// Creation of player object
        /// </summary>
        /// <param name="isAI"> True if the player object is an AI player </param>
        /// <param name="name"> Player's name as a string </param>
        /// <param name="location"> Player's location as a string </param>
        public Player(int playerOrder, bool isAI, string name, string color, int spawn)
        {
            this.goal = new int[4] { 0, 0, 0, 0 };
            this.isAI = isAI;
            if (name == null)
            {
                this.name = string.Format("Player{0}", playerOrder);
            }
            else
            {
                this.name = name;
            }
            switch (color.ToUpper())
            {
                case "R":
                    this.color = Colors.RED;
                    break;
                case "G":
                    this.color = Colors.GREEN;
                    break;
                case "B":
                    this.color = Colors.BLUE;
                    break;
                case "Y":
                    this.color = Colors.YELLOW;
                    break;
                default:
                    Console.WriteLine("THIS SHOULD NEVER BE PRINTED! PLAYER CLASS COLOR ASSIGNMENT.");
                    break;
            }
            this.spawn = spawn;
            this.order = -1;
        }
        // Move a Pawn
        public void MovePawn(int roll, Board board)
        {
            // Gets index of valid moves
            Console.WriteLine("Which Pawn Do You Want To Move?");
            List<int> validPawnIndex = new List<int>();
            for (int i = 0; i < this.pawns.Length; i++)
            {
                if (this.pawns[i].CanMove(roll, board))
                {
                    validPawnIndex.Add(i);
                    Console.WriteLine("{0}: Pawn {1} at {2}", validPawnIndex.Count, i + 1, this.pawns[i].location);
                }
            }
            // Ask player which pawn to move
            int choice = -1;
            bool valid;
            do
            {
                Console.Write("->");
                int.TryParse(Console.ReadLine(), out choice);
                if (choice <= validPawnIndex.Count && choice > 0)
                {
                    valid = true;
                }
                else
                {
                    Console.WriteLine("Please Enter a Valid Input (1-{0}).", validPawnIndex.Count); valid = false;
                }
            } while (!(valid));
            // Gets oldindex
            int oldIndex = this.pawns[validPawnIndex[choice - 1]].location;
            // Gets newIndex
            int newIndex;
            if ((newIndex = this.pawns[validPawnIndex[choice - 1]].location + roll) > 27)
            {
                newIndex -= 28;
            }
            else
            {
                newIndex = this.pawns[validPawnIndex[choice - 1]].location + roll;
            }
            // Checks for pawns already in newIndex and updates board
            if ( !(board.spaces[newIndex].color.Equals(this.color)) )
            {
                if ( !(board.spaces[newIndex].color.Equals("Empty")) )
                {
                    // Displays pawn being sent home
                    string color = board.spaces[newIndex].color;
                    Console.WriteLine("{0} Sent {1}'s Pawn Back To Spawn By Landing On It!", this.color, color);
                    // Reset pawn status
                    board.spaces[newIndex].inHome = true;
                    board.spaces[newIndex].distance = 0;
                    board.spaces[newIndex].location = -1;
                    // Update board
                    board.spaces[newIndex] = this.pawns[validPawnIndex[choice - 1]];
                    board.spaces[oldIndex] = new Pawn(-1, "Empty");
                }
            }
            // If the space is empty
            if (board.spaces[newIndex].color.Equals("Empty"))
            {
                board.spaces[newIndex] = this.pawns[validPawnIndex[choice - 1]];
                board.spaces[oldIndex] = new Pawn(-1, "Empty");
            }
            // Update selected pawn location
            if (this.pawns[validPawnIndex[choice - 1]].location + roll > 27)
            {

                this.pawns[validPawnIndex[choice - 1]].location = this.pawns[validPawnIndex[choice - 1]].location + roll - 28;
            }
            else
            {
                this.pawns[validPawnIndex[choice - 1]].location += roll;
            }
            this.pawns[validPawnIndex[choice - 1]].distance += roll;
            // Checks if pawn is in goal
            if (this.pawns[validPawnIndex[choice - 1]].inGoal)
            {
                Console.WriteLine("{0} moved a pawn to their goal!", this.name);
            }
            else
            {
                Console.Write("Moved Pawn {0} To {1}", validPawnIndex[choice - 1] + 1, this.pawns[validPawnIndex[choice - 1]].location);
            }
            Console.Write("\nPress Enter To Continue...");
            Console.ReadLine();
        }

        // Free a Pawn
        public void FreePawn()
        {
            // Gets index of valid moves
            List<int> validPawnIndex = new List<int>();
            for (int i = 0; i < this.pawns.Length; i++)
            {
                if (this.pawns[i].inHome)
                {
                    validPawnIndex.Add(i);
                    Console.WriteLine("{0}: Free Pawn {1}", validPawnIndex.Count, i + 1);
                }
            }
            // Ask player which pawn to move
            int choice = -1;
            bool valid;
            do
            {
                Console.Write("->");
                int.TryParse(Console.ReadLine(), out choice);
                if (choice <= validPawnIndex.Count && choice > 0)
                {
                    valid = true;
                }
                else
                {
                    Console.WriteLine("Please Enter a Valid Input (1-{0}).", validPawnIndex.Count);
                    valid = false;
                }
            } while (!(valid));
            // Moves pawn out into spawn
            this.pawns[validPawnIndex[choice - 1]].location = this.spawn;
            this.pawns[validPawnIndex[choice - 1]].inHome = false;
            Console.Write("Moved Pawn {0} To {1}\nPress Enter To Continue...", validPawnIndex[choice - 1] + 1, this.pawns[validPawnIndex[choice - 1]].location);
            Console.ReadLine();
        }
        // Checks if player can move pawns
        public bool CanMove()
        {
            foreach (Pawn pawn in pawns)
            {
                if (!(pawn.inHome) && !(pawn.inGoal)) { return true; }
            }
            return false;
        }
        // Checks if pawns are in home
        public bool IsHome()
        {
            foreach (Pawn pawn in pawns)
            {
                if (pawn.inHome) return true;
            }
            return false;
        }

        // Checks if player has won the game
        public bool CheckWon()
        {
            int total = 0;
            foreach (Pawn pawn in pawns)
            {
                if (pawn.inGoal) { total++; }
            }
            if (total == 4) { return true; }
            return false;
        }
        public override string ToString()
        {
            return name;
        }
    }
    /// <summary>
    /// Runs all the game functions neatly
    /// </summary>
    internal class Program
    {
        const int MAX_PLAYERS = 4;
        static void Main(string[] args)
        {
            // USEFULE VARIABLES 
            Random rng = new Random();

            // INITIAL WELCOM TO TROUBLE GAME
            // SHOULD NEVER REPEAT
            // Use to center text: ("{0," + ((Console.WindowWidth / 2) + (TEXTHERE.Length / 2)) + "}", TEXTHERE));
            Console.Write(
                "Welcome to Pop-O-Matic Trouble!\n" +
                "===============================\n\n" +
                "Rules:\n" +
                "======\n" +
                "Trouble is easy to play. Players will take turns rolling a die.\n" +
                "Roll a 6 to start a piece on the board and get all 4 peices around the board before\n" +
                "any other player. Land on another player peice to send them back to the start!\n\n" +
                "Good Luck! Have Fun!\n\n" +
                "Press enter to continue...");
            Console.ReadLine();

            // GET TOTAL NUMBER OF REAL PLAYERS
            int numPlayers = -1;
            string numPlayersInput = "";
            Console.Write("\nHow many Players will there be in this game? (1-4) ");
            while (numPlayers == -1)
            {
                numPlayersInput = Console.ReadLine();
                switch (numPlayersInput)
                {
                    case "1":
                        numPlayers = 1;
                        break;
                    case "2":
                        numPlayers = 2;
                        break;
                    case "3":
                        numPlayers = 3;
                        break;
                    case "4":
                        numPlayers = 4;
                        break;
                    default:
                        Console.Write("Please enter a valid number of players. (1-4) ");
                        break;
                }
            }

            // GET HOW MANY PLAYERS ARE AI
            int minAI = 0;
            if (numPlayers == 1)
            {
                minAI = 1;
            }
            int numAI = -1;
            if (numPlayers != 4)
            {
                string numAIInput = "";
                Console.Write("\nHow many AI players will there be? ({0}-{1}) ", minAI, MAX_PLAYERS - numPlayers);
                while (numAI == -1)
                {
                    numAIInput = Console.ReadLine();
                    switch (numAIInput)
                    {
                        case "0":
                            numAI = 0;
                            break;
                        case "1":
                            numAI = 1;
                            break;
                        case "2":
                            numAI = 2;
                            break;
                        case "3":
                            numAI = 3;
                            break;
                        default:
                            Console.Write("Please enter a valid number of AI players. (0-{0}) ", MAX_PLAYERS - numPlayers);
                            break;
                    }
                    if (numAI + numPlayers > 4)
                    {
                        numAI = -1;
                        Console.Write("Too many AI players. Please enter a valid number of AI players. (0-{0}) ", MAX_PLAYERS - numPlayers);
                    }
                }
            }
            else
            {
                numAI = 0;
            }

            // PLAYER CREATION AND COLOR SELECTION
            // availableColors: Keeps track of all colors currently not in use by the players
            string[] availableColors = new string[] { "R", "G", "B", "Y" };
            Player[] players = new Player[numPlayers + numAI];
            string playerName = "UNIDENTIFIED_PLAYER_NAME";
            string playerColor = "UNIDENTIFIED_PLAYER_COLOR";
            //
            // CREATE A FUNCTION FOR PLAYER SPAWNS
            //
            int playerSpawn = 0;
            for (int i = 0; i < numPlayers; i++)
            {
                Console.Write("\nPlease enter the name for Player{0}: ", i + 1);
                playerName = Console.ReadLine();
                Console.Write("Please pick a color to play as ({0}): ", string.Join(",", availableColors));
                while (players[i] == null)
                {
                    playerColor = Console.ReadLine();
                    switch (playerColor.ToUpper())
                    {
                        case "R":
                            if (availableColors.Contains(playerColor.ToUpper()))
                            {
                                players[i] = new Player(i + 1, false, playerName, playerColor, playerSpawn);
                                List<string> tempColors = new List<string>(availableColors);
                                tempColors.Remove(playerColor.ToUpper());
                                availableColors = tempColors.ToArray();
                            }
                            else
                            {
                                Console.Write("That color has already been chosen. Please enter a valid color ({0}): ", string.Join(",", availableColors));
                            }
                            break;
                        case "G":
                            if (availableColors.Contains(playerColor.ToUpper()))
                            {
                                players[i] = new Player(i + 1, false, playerName, playerColor, playerSpawn);
                                List<string> tempColors = new List<string>(availableColors);
                                tempColors.Remove(playerColor.ToUpper());
                                availableColors = tempColors.ToArray();
                            }
                            else
                            {
                                Console.Write("That color has already been chosen. Please enter a valid color ({0}): ", string.Join(",", availableColors));
                            }
                            break;
                        case "B":
                            if (availableColors.Contains(playerColor.ToUpper()))
                            {
                                players[i] = new Player(i + 1, false, playerName, playerColor, playerSpawn);
                                List<string> tempColors = new List<string>(availableColors);
                                tempColors.Remove(playerColor.ToUpper());
                                availableColors = tempColors.ToArray();
                            }
                            else
                            {
                                Console.Write("That color has already been chosen. Please enter a valid color ({0}): ", string.Join(",", availableColors));
                            }
                            break;
                        case "Y":
                            if (availableColors.Contains(playerColor.ToUpper()))
                            {
                                players[i] = new Player(i + 1, false, playerName, playerColor, playerSpawn);
                                List<string> tempColors = new List<string>(availableColors);
                                tempColors.Remove(playerColor.ToUpper());
                                availableColors = tempColors.ToArray();
                            }
                            else
                            {
                                Console.Write("That color has already been chosen. Please enter a valid color ({0}): ", string.Join(",", availableColors));
                            }
                            break;
                        default:
                            Console.Write("Please enter a valid color ({0}): ", string.Join(",", availableColors));
                            break;
                    }
                }
            }

            // AI PLAYER CREATION
            string[] AINames = { "Bot Linda", "Bot Karen", "Bot Greg", "Bot Jill", "Bot Henry", "Bot Tom", "Bot Sandy",
                "Bot Frank", "Bot Bill", "Bot Emily", "Bot Steven", "Bot Ashley" };
            string aiName = "UNIDENTIFIED_AI_NAME";
            string aiColor = "UNIDENTIFIED_AI_COLOR";
            int aiSpawn = 0;
            for (int i = 0; i < numAI; i++)
            {
                aiName = AINames[rng.Next(0, AINames.Length)];
                aiColor = availableColors[rng.Next(0, availableColors.Length)];
                players[i + numPlayers] = new Player(-1, true, aiName, aiColor, aiSpawn);
                List<string> tempNames = new List<string>(AINames);
                tempNames.Remove(aiName);
                AINames = tempNames.ToArray();
                List<string> tempColors = new List<string>(availableColors);
                tempColors.Remove(aiColor.ToUpper());
                availableColors = tempColors.ToArray();
            }

            // SPAWN BOARD
            Console.WriteLine("\nCreating Board...");
            Board board = Utility.CreateBoard(players);
            Console.WriteLine("Board Complete!");

            // GIVE PLAYERS PAWNS
            Console.WriteLine("Spawning Pawns...");
            Utility.CreatePawns(players);
            Console.WriteLine("Pawns Spawned!");

            // TURN SELECTION
            Console.Write("\nPress Enter To Roll For Turn...");
            Console.ReadLine();
            Utility.firstRoll(players, rng);
            Console.Write("\n\nPress Enter To Start The Game...");
            Console.ReadLine();

            // RUN CURRENT PLAYER'S TURN UNTIL GAME IS COMPLETE
            bool wonGame = false;
            while (!wonGame)
            {
                // TEMP SKIP GAME
                //break;
                for (int i = 0; i < players.Length; i++)
                {
                    foreach (Player player in players)
                    {
                        if (player.order == i)
                        {
                            Utility.playerTurn(player, rng, board);
                            wonGame = player.CheckWon();
                            // Stops game if someone has won
                            if (wonGame)
                            {
                                Console.WriteLine("{0} HAS WON THE GAME!", player.name);
                                break;
                            }
                        }
                    }
                    // Stops game if someone has won
                    if (wonGame)
                    {
                        break;
                    }
                }
            }

            // CURRENT EOF AND TESTING
            Utility.PrintInfo(players);
            Utility.PrintTime();
            Console.Write("\nPress Enter To End Game...");
            Console.ReadLine();
        }
    }
}

