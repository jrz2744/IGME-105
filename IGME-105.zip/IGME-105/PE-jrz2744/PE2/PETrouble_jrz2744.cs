using System;

/*
 * Program: PETrouble_jrz2744.cs
 * Author: Jake Zoltun
 * Email: jrz2744@rit.edu
 * Purpose: Testing variables
 * Git Link: https://kgcoe-git.rit.edu/jrz2744/PE-jrz2744/-/tree/main/PE2
 * Date: 1/26/2023
 * Modifications: Moved game layout to text file -> PETrouble_jrz2744.txt
 *                Started created main method and helper functions
 */

namespace PETrouble_jrz2744
{
    /// <summary>
    /// Main class which stores the players and runs the game to completion.
    /// </summary>
    private class TroubleGame
    {
        static void Main(string[] args)
        {
            string playerName = Console.ReadLine("Player1 please enter your name: ");
            Player player = new Player(playerName, "start");
            Console.WriteLine("Welcome " + player.getName);
        }
    }

    /// <summary>
    /// Player class which stores retrievable player/ai data
    /// </summary>
    private class Player
    {
        /// <summary>
        /// This is the player object which will contain helper functions to store data
        /// </summary>
        /// <param name="name"> string player's name </param>
        /// <param name="location"> string player's location </param>
        /// <returns></returns>
        Player player(string name, string location)
        {
            private string name = name;
            private string location = location;
        }

        /// <summary>
        /// This function returns the player's private name as a string
        /// </summary>
        /// <param name="player"></param>
        /// <returns> string name </returns>
        string getName(Player player)
        {
            return player.name;
        }

        /// <summary>
        /// This function returns the player's private location as a string
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        int getlocation(Player player)
        {
            return player.location;
        }
    }
}
