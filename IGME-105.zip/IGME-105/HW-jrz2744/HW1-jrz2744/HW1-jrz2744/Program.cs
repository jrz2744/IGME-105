using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq.Expressions;
using System.Xml.Serialization;

/* Program: HW1-jrz2744/Program.cs
 * Author: Jake Zoltun 
 * Email: jrz2744@rit.edu 
 * Purpose: Homework 1
 * Git Link: https://kgcoe-git.rit.edu/jrz2744/HW-jrz2744/HW1-jrz2744
 * Date: 2/11/2023 
 * Modifications: 2/11/23 - Complete intro to game getting character name and introducing Merlin the wizard - jrz
 *                2/11/23 - Added walking action to get find Merlin's tower - jrz
 *                2/13/23 - Fixed coding standards for const variables - jrz
 *                2/13/23 - Added note section for HW1 in particular
 *                2/13/23 - Added WriteRPG() learned/got something stlye, style 2
 *                2/13/23 - Added notes when finding amulet and wizard's name/tower
 */

/// IMPORTANT NOTE FOR HW1
/// To get to the walking section the player must follow Merlin when prompted or else the walking section will be skipped
/// PS if you can't beat the walking section the magic number is on line 546
/// ******************** ATTENTION GRABBER :D ********************

// TODO: OUTLINE FOR STORY HERE
// OUTLINE

namespace HW1_jrz2744
{
    /// <summary>
    /// Class for holding methods relating to output text
    /// </summary>
    public class Utility
    {
        public static void CreatePageBreak()
        {
            Console.WriteLine(String.Format("{0}", new String('\n', 40)));
        }
        /// <summary>
        /// Prints text RPG style one letter at a time :)
        /// </summary>
        /// <param name="text"> Input text to be printed character by character </param>
        public static void WriteRPG(string text, int speed, int style)
        {
            // Finds style of text
            switch (style)
            {
                // Style 0: Normal Text / Dialogue
                case 0:
                    Console.ForegroundColor = ConsoleColor.Yellow; break;
                // Style 1: Narration
                case 1:
                    Console.ForegroundColor = ConsoleColor.DarkGreen; break;
                // Style 2: Learned/Got Something
                case 2:
                    Console.ForegroundColor = ConsoleColor.DarkCyan; break;
                // Style 3: ????
                case 3:
                    break;
               // Style -1: Normal Text / Dialogue
                default:
                    Console.ForegroundColor = ConsoleColor.White; break;
            }
            // Prints text out
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(speed);
            }

            // Sets Text color back to normal
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
    internal class Program
    {
        /// <summary>
        /// Object class for the player to store information
        /// </summary>
        public class Player
        {
            
            public string name { get; set; }
            public int textSpeed { get; set; }
            public string accessory { get; set; }
            public string[] inventory { get; set; }

            public Player(string name, int textSpeed)
            {
                switch (name)
                {
                    case null:
                        this.name = "You"; break;
                    default:
                        this.name = name; break;
                }
                if (textSpeed >= 0)
                {
                    this.textSpeed = textSpeed;
                }
                this.accessory = "None";
                this.inventory = new string[4];
            }

            public void InventoryAdd(string item)
            {
                List<string> tempInventory = new List<string>(inventory);
                tempInventory.Add(item);
                this.inventory = tempInventory.ToArray();
            }

            public override string ToString()
            {
                return this.name;
            }
        }

        /* EMPTY QUESTION
        if (true)
                {
                    Utility.WriteRPG(PUTQUESTIONHERE, player.textSpeed, -1);
                    string choice1 = ;
                    string choice2 = ;
                    string choice3 = ;
                    Utility.WriteRPG(string.Format("\n1: {0}\n2: {1}\n3: {2}\n->", choice1, choice2, choice3), player.textSpeed, -1);
                    string choice = Console.ReadLine();
                    bool validChoice = false;
                    while (!validChoice)
                    {
                        switch (choice)
                        {
                            case "1":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice1), player.textSpeed, -1);
                                validChoice = true; break;
                            case "2":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice2), player.textSpeed, -1);
                                validChoice = true; break;
                            case "3":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice3), player.textSpeed, -1);
                                validChoice = true; break;
                            default:
                                Utility.WriteRPG(string.Format("\n{0} is invalid.\n->", choice), player.textSpeed, -1); choice = Console.ReadLine(); break;
                        }
                    }
                    PUTREPLYTOQUESTIONHERE
                }
         */

        /// <summary>
        /// Main function which runs game
        /// </summary>
        static async Task Main(string[] args)
        {
            // CREATE STARTING PLAYER OBJECT
            Player player = new Player(null, 30);

            // VARIABLES
            // True if the player wants to contine playing the game or restart
            bool continueGame = true;

            // WELCOME TO GAME - Plays once at the start of game
            Console.Write("Welcome to Faerie Realm: Far From Home!\n\n" +
                "This is a classic text based RPG with many endings (WIP) where choices matter. " +
                "In general anytime dialogue ends with \"...\" you will have to press enter to continue. " +
                "If not then you will either have to wait a set amount of time or answer a question.\n" +
                "Press enter to view an example question...");
            Console.ReadLine();
            // Using an if statement to contain string variables so they are gone after use
            // Will most likely be using this a lot throughout
            if (true)
            {
                Utility.WriteRPG("\nChoice your text speed (Currently set to Normal):", player.textSpeed, -1);
                string choice1 = "Normal";
                string choice2 = "Fast";
                string choice3 = "Instant - Disables RPG Style Text";
                Utility.WriteRPG(string.Format("\n1: {0}\n2: {1}\n3: {2}\n->", choice1, choice2, choice3), player.textSpeed, -1);
                string choice = Console.ReadLine();
                bool validChoice = false;
                while (!validChoice)
                {
                    switch (choice)
                    {
                        case "1":
                            player.textSpeed = 30;
                            Utility.WriteRPG("\nYou picked Normal speed text. This cannot be changed later.", player.textSpeed, -1);
                            validChoice = true; break;
                        case "2":
                            player.textSpeed = 10;
                            Utility.WriteRPG("\nYou picked Fast speed text. This cannot be changed later.", player.textSpeed, -1);
                            validChoice = true; break;
                        case "3":
                            player.textSpeed = 0;
                            Utility.WriteRPG("\nYou picked Instant speed text. This cannot be changed later.", player.textSpeed, -1);
                            validChoice = true; break;
                        default:
                            Utility.WriteRPG("\nPlease enter a valid choice (1, 2, 3):", player.textSpeed, -1); choice = Console.ReadLine(); break;
                    }
                }
                await Task.Delay(1200);
                Utility.WriteRPG("\nThis first choice didn't impact the story, but some choices may have dire consequences later down the line...", player.textSpeed, -1);
                Console.ReadLine();
            }
            Utility.WriteRPG("\nYou're ready to start your adventure! Press enter to conitue...", player.textSpeed, -1);
            Console.ReadLine();
            Utility.CreatePageBreak();

            // GAME LOOP - Keeps repeating game until the user quits
            while (continueGame)
            {
                // START OF GAME :D

                // WIZARD FINDS YOU
                await Task.Delay(2000);
                Utility.WriteRPG("\n...", player.textSpeed, -1);
                await Task.Delay(2000);
                Utility.WriteRPG("\n...", player.textSpeed, -1);
                await Task.Delay(2000);
                Utility.WriteRPG("\n[???] Rie seba lit yamieti litet teser li lisip emurad?!...", player.textSpeed, -1);
                Console.ReadLine();
                Utility.WriteRPG(string.Format("({0}) You open your eyes to find a strange man standing before you, " +
                    "his long grey beard and weathered face illuminated by the moonlight. He was wearing a deep " +
                    "purple robe, and held a staff firmly in his hands. He had a kindly smile on his face, although " +
                    "you could tell he was confused by your presence...", player.name), 
                    player.textSpeed, 1);
                Console.ReadLine();

                // WIZARD QUESTION 1
                if (true)
                {
                    Utility.WriteRPG("[???] Naf initer viy caruci imafoke faha teti kinebe?", player.textSpeed, -1);
                    string choice1 = "What?";
                    string choice2 = "No?";
                    string choice3 = "Yes?";
                    Utility.WriteRPG(string.Format("\n1: {0}\n2: {1}\n3: {2}\n->", choice1, choice2, choice3), player.textSpeed, -1);
                    string choice = Console.ReadLine();
                    bool validChoice = false;
                    while (!validChoice)
                    {
                        switch (choice)
                        {
                            case "1":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice1), player.textSpeed, -1);
                                validChoice = true; break;
                            case "2":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice2), player.textSpeed, -1);
                                validChoice = true; break;
                            case "3":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice3), player.textSpeed, -1);
                                validChoice = true; break;
                            default:
                                Utility.WriteRPG(string.Format("\n{0} is invalid.\n->", choice), player.textSpeed, -1); choice = Console.ReadLine(); break;
                        }
                    }
                    // Wizard's reply 1
                    await Task.Delay(1200);
                    Utility.WriteRPG("\n[???] Tovep ra lesatir. Ibabiyal diri bo roxikam tap rugorin eyurom tec oma tipieg?", player.textSpeed, -1);
                    await Task.Delay(1200);
                }

                // WIZARD QUESTION 2
                if (true)
                {
                    Utility.WriteRPG("\n[???] Banose den otar? Neyo bibode ute teli!?", player.textSpeed, -1);
                    string choice1 = "I don't understand what you're asking.";
                    string choice2 = "No?";
                    string choice3 = "Yes?";
                    Utility.WriteRPG(string.Format("\n1: {0}\n2: {1}\n3: {2}\n->", choice1, choice2, choice3), player.textSpeed, -1);
                    string choice = Console.ReadLine();
                    bool validChoice = false;
                    while (!validChoice)
                    {
                        switch (choice)
                        {
                            case "1":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice1), player.textSpeed, -1);
                                validChoice = true; break;
                            case "2":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice2), player.textSpeed, -1);
                                validChoice = true; break;
                            case "3":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice3), player.textSpeed, -1);
                                validChoice = true; break;
                            default:
                                Utility.WriteRPG(string.Format("\n{0} is invalid.\n->", choice), player.textSpeed, -1); choice = Console.ReadLine(); break;
                        }
                    }
                    // Wizard's reply 2
                    await Task.Delay(800);
                    Utility.WriteRPG(string.Format("\n({0}) You feel a sudden burst of energy around yourself. " +
                        "You look up to see the stanger pointing his staff at you. His wise eyes seem to pierce " +
                        "your soul. He begins speaking again but this time much louder...", player.name),
                        player.textSpeed, 1);
                    Console.ReadLine();
                    Utility.WriteRPG("[???] Werati etomot cocel pinof arenesa nocaf! Cap girale tielor asop nana lanaden vedem icixo!", 
                        player.textSpeed, 0);
                    await Task.Delay(400);
                    Utility.WriteRPG(string.Format("\n({0}) Suddenly a bright white light shoots from the tip of his " +
                        "staff and envelopes you in a shimmering aura. \r\nThis feeling is unlike anything you have ever " +
                        "experienced before. It's not painful but it doesn't feel right...", player.name), 
                        player.textSpeed, 1);
                    Console.ReadLine();
                    Utility.WriteRPG("\n...", 
                        player.textSpeed, -1);
                    await Task.Delay(1200);
                }

                // CREATE WIZARD PLAYER OBJECT
                Player wizard = new Player("???", 40);

                // ASK WIZARD QUESTIONS
                if (true)
                {
                    Utility.WriteRPG(string.Format("\n\n[{0}] That should be better. I take it you're not from around here are you?", wizard.name), player.textSpeed, -1);
                    string choice1 = "What did you just do to me?";
                    string choice2 = "Where am I?";
                    string choice3 = "Who are you?";
                    string choice4 = "No. Where on Earth are we?";
                    string choice = null;
                    bool validChoice = false;
                    while (!validChoice)
                    {
                        Utility.WriteRPG(string.Format("\n1: {0}\n2: {1}\n3: {2}\n4: {3}\n->", choice1, choice2, choice3, choice4), player.textSpeed, -1);
                        choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "1":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice1), player.textSpeed, -1);
                                await Task.Delay(800);
                                Utility.WriteRPG(string.Format("\n[{0}] I just cast a simple spell on you which allows you to " +
                                    "understand my language.\n", wizard.name), 
                                    player.textSpeed, -1);
                                await Task.Delay(200);
                                Utility.WriteRPG(string.Format("[{0}] You're really not from around here are you.\n", wizard.name), 
                                    player.textSpeed, -1);
                                break;
                            case "2":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice2), player.textSpeed, -1);
                                await Task.Delay(800);
                                Utility.WriteRPG(string.Format("\n[{0}] Where're in the Mystic Woodland Glade.", wizard.name), 
                                    player.textSpeed, -1);
                                Utility.WriteRPG(string.Format("\n[{0}] It's a rather peaceful part of the Kingdom of the " +
                                    "Faerie Realm.\n", wizard.name),
                                    player.textSpeed, -1);
                                await Task.Delay(400);
                                Utility.WriteRPG(string.Format("({0}) As you look around you become entranced by the surrounding " +
                                    "enchanted forest filled with towering trees draped in moss. The air is filled with the sound of " +
                                    "birdsong, while patches of sunlight filter through the dense canopy of foliage. Wildflowers and " +
                                    "ferns carpet the forest floor, and an ancient creek meanders through the glade, adding to the " +
                                    "tranquil atmosphere.\n", player.name),
                                    player.textSpeed, 1);
                                await Task.Delay(800);
                                Utility.WriteRPG(string.Format("[{0}] It's quite the sight to behold.\n", wizard.name), 
                                    player.textSpeed, -1);
                                break;
                            case "3":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}\n", player.name, choice3), player.textSpeed, -1);
                                await Task.Delay(800);
                                Utility.WriteRPG(string.Format("[{0}] I'm Merlin, the wizard of the Mystic Woodland Glade.\n", wizard.name), 
                                    player.textSpeed, -1);
                                // Found Merlin's name
                                wizard.name = "Merlin";
                                await Task.Delay(200);
                                Utility.WriteRPG(string.Format("\t+Wizard's Name\n"), 
                                    player.textSpeed, 2);
                                Utility.WriteRPG(string.Format("[{0}] I have been here for many years, tending to the magical " +
                                    "creatures that inhabit this enchanted forest.\n", wizard.name), 
                                    player.textSpeed, -1);
                                await Task.Delay(200);
                                Utility.WriteRPG(string.Format("[{0}] I'm a master of the arcane arts, and I take great pleasure " +
                                    "in sharing my knowledge and wisdom with those who seek it.\n", wizard.name), 
                                    player.textSpeed, -1);
                                break;
                            case "4":
                                Utility.WriteRPG(string.Format("\n[{0}] {1}", player.name, choice4), player.textSpeed, -1);
                                await Task.Delay(800);
                                Utility.WriteRPG(string.Format("\n[{0}] Ah, my friend, you have come to a place that is beyond " +
                                    "Earth.", wizard.name), 
                                    player.textSpeed, -1);
                                await Task.Delay(200);
                                Utility.WriteRPG(string.Format("\n[{0}] We're in a magical realm far from the mortal" +
                                    " world.", wizard.name),
                                    player.textSpeed, -1);
                                await Task.Delay(200);
                                Utility.WriteRPG(string.Format("\n[{0}] Here, the laws of nature are different, and the power " +
                                    "of magic is strong.", wizard.name),
                                    player.textSpeed, -1);
                                await Task.Delay(200);
                                Utility.WriteRPG(string.Format("\n[{0}] Welcome to the Faerie Realm!...", wizard.name),
                                    player.textSpeed, -1);
                                validChoice = true; break;
                            default:
                                Utility.WriteRPG(string.Format("\n{0} is invalid.\n->", choice), player.textSpeed, -1); choice = Console.ReadLine(); break;
                        }
                    }
                    Console.ReadLine();
                    // Didn't find Merlin's name
                    if (wizard.name.Equals("???"))
                    {
                        Utility.WriteRPG(string.Format("\n[{0}] I'm Merlin by the way.", wizard.name),
                            player.textSpeed, -1);
                        await Task.Delay(200);
                        wizard.name = "Merlin";
                    }
                }

                // GET PLAYERS NAME
                if (true)
                {
                    Utility.WriteRPG(string.Format("\n[{0}] What's your name stranger?", wizard.name),
                        player.textSpeed, -1);
                    Utility.WriteRPG("\n->", player.textSpeed, -1);
                    string choice = Console.ReadLine();
                    bool validChoice = false;
                    while (!validChoice)
                    {
                        switch (choice)
                        {
                            case null:
                                Utility.WriteRPG(string.Format("\n{0} is invalid.\n->", choice), 
                                    player.textSpeed, -1); 
                                choice = Console.ReadLine(); break;
                            case "":
                                Utility.WriteRPG(string.Format("\n{0} is invalid.\n->", choice),
                                    player.textSpeed, -1);
                                choice = Console.ReadLine(); break;
                            default:
                                Utility.WriteRPG(string.Format("[{0}] I'm {0}.", choice),
                                    player.textSpeed, -1);
                                player.name = choice; validChoice = true; break;
                        }
                    }
                    // GET AMULET
                    await Task.Delay(800);
                    Utility.WriteRPG(string.Format("\n[{0}] Well, it's nice to meet you {1}.", wizard.name, player.name), 
                        player.textSpeed, -1);
                    await Task.Delay(200);
                    Utility.WriteRPG(string.Format("\n[{0}] Although finding you asleep in a forest was quite out of the ordinary...", wizard.name),
                        player.textSpeed, -1);
                    Console.ReadLine();
                    Utility.WriteRPG(string.Format("\n[{0}] I'm in quite the rush right now, but take this gift.", wizard.name),
                        player.textSpeed, -1);
                    await Task.Delay(200);
                    Utility.WriteRPG(string.Format("\n[{0}] It will allow you to contact me whenever you need my help.", wizard.name),
                        player.textSpeed, -1);
                    await Task.Delay(200);
                    Utility.WriteRPG(string.Format("\n[{0}] But for now, I need to be alone.", wizard.name),
                        player.textSpeed, -1);
                    await Task.Delay(200);
                    Utility.WriteRPG(string.Format("\n({0}) Merlin raises his staff once again but with a blue glow...", player.name),
                        player.textSpeed, 1);
                    Console.ReadLine();
                    Utility.WriteRPG(string.Format("({0}) By the power of the moon, come forth to the forest!", player.name),
                        player.textSpeed, 0);
                    await Task.Delay(200);
                    Utility.WriteRPG(string.Format("\n({0}) Suddenly a bright blue light shoots from the tip of his staff and into the air. " + 
                        "The world around you grows darker except for a single beam of moonlight. In it floats an amulet slowly falling " +
                        "down from the sky above until it stops in front of you a couple feet off the ground. Take the amulet...", player.name),
                        player.textSpeed, 1);
                    Console.ReadLine();
                    Utility.WriteRPG(string.Format("\n({0}) You reach out and pick up the amulet...", player.name),
                        player.textSpeed, 1);
                    Console.ReadLine();
                    Utility.WriteRPG(string.Format("\t+Lunarlight Amulet\n"),
                                    player.textSpeed, 2);
                }

                // USE AMULET
                if (true)
                {
                    Utility.WriteRPG(string.Format("\n({0}) What will you do with it?", player.name), player.textSpeed, 1);
                    string choice1 = "Investigate amulet.";
                    string choice2 = "Put the amulet on.";
                    string choice3 = "Put the amulet away.";
                    string choice;
                    bool validChoice = false;
                    while (!validChoice)
                    {
                        Utility.WriteRPG(string.Format("\n1: {0}\n2: {1}\n3: {2}\n->", choice1, choice2, choice3), player.textSpeed, -1);
                        choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "1":
                                Utility.WriteRPG(string.Format("\n({0}) The amulet is in the shape of a silver crescent moon, engraved with ancient " + 
                                    "runes and symbols. Hanging from the crescent moon is a single white moonstone glowing with magical energy.", player.name), 
                                    player.textSpeed, 1); 
                                break;
                            case "2":
                                Utility.WriteRPG(string.Format("\n({0}) As you put the amulet on you feel a similar power to that of Merlin's first spell. " + 
                                    "Its light soon fades and the amulet's glow subsides.", player.name), 
                                    player.textSpeed, 1);
                                // First item in accessory slot, eventually will need to create inventory system and check if it is full before adding items
                                player.accessory = "Moon Amulet"; validChoice = true; break;
                            case "3":
                                Utility.WriteRPG(string.Format("\n({0}) You put the amulet into your pocket and its light soonly fades.", player.name), 
                                    player.textSpeed, 1);
                                // First item in inventory, eventually will need to create inventory system and check if it is full before adding items
                                player.InventoryAdd("Moon Amulet"); validChoice = true; break;
                            default:
                                Utility.WriteRPG(string.Format("\n{0} is invalid.\n->", choice), player.textSpeed, -1); choice = Console.ReadLine(); break;
                        }
                    }
                    // Merlin leaves
                    await Task.Delay(1000);
                    Utility.WriteRPG(string.Format("\n[{0}] I'll meet with you again soon. Good luck {1}.", wizard.name, player.name),
                                    player.textSpeed, -1);
                    await Task.Delay(200);
                }

                // MERLIN LEAVES
                if (true)
                {
                    Utility.WriteRPG(string.Format("\n({0}) Without hesitation Merlin begins to walk off into the depths of the forest...", player.name), 
                        player.textSpeed, 1); 
                    string choice1 = "Tail him into the forest against Merlin's words.";
                    string choice2 = "Watch as Merlin disappears into the forest.";
                    Utility.WriteRPG(string.Format("\n1: {0}\n2: {1}\n->", choice1, choice2), player.textSpeed, -1);
                    string choice = Console.ReadLine();
                    bool validChoice = false;
                    while (!validChoice)
                    {
                        switch (choice)
                        {
                            case "1":
                                Utility.WriteRPG(string.Format("\n({0}) You start following Merlin into the depths of the forest.", player.name), 
                                    player.textSpeed, 1);
                                validChoice = true; break;
                            case "2":
                                Utility.WriteRPG(string.Format("\n({0}) You sit in silence as you watch Merlin disappear into the darker depths of the forest.", player.name, choice2), 
                                    player.textSpeed, 1);
                                validChoice = true; break;
                            default:
                                Utility.WriteRPG(string.Format("\n{0} is invalid.\n->", choice), player.textSpeed, -1); choice = Console.ReadLine(); break;
                        }
                    }
                    
                    // MERLIN WALKING GAME - Gives access to Merlin's tower early if done correctly
                    if (choice == "1")
                    {
                        Utility.WriteRPG(string.Format("\n({0}) If you get too close to Merlin he'll spot you. If you get too far you'll lose him in the depths of the forest.", player.name),
                                    player.textSpeed, 1);
                        const int TOTAL_DISTANCE = 800;
                        const int DETECTION_RANGE = 100;
                        const int MAX_RANGE = 300;
                        const int MERLIN_CONSTANT = 50;
                        int playerDistance = 0;
                        int merlinDistance = 150;
                        int tryMove = -1;
                        bool detected = false;
                        validChoice = false;
                        while (!detected)
                        {
                            // Get player steps to move
                            while (!validChoice)
                            {
                                Utility.WriteRPG(string.Format("\nHow many steps will you take: "),
                                    player.textSpeed, -1);
                                int.TryParse(Console.ReadLine(), out tryMove);
                                if (tryMove > 0)
                                {
                                    validChoice = true;
                                }
                                else
                                {
                                    Utility.WriteRPG(string.Format("Invalid number of steps.", player.name),
                                        player.textSpeed, -1);
                                }
                            }
                            // Player moves
                            playerDistance += tryMove;
                            Utility.WriteRPG(string.Format("({0}) You take {1} step(s).", player.name, tryMove),
                                        player.textSpeed, 1);
                            tryMove = -1; validChoice = false;
                            // Merlin moves
                            if (merlinDistance < TOTAL_DISTANCE)
                            {
                                merlinDistance += MERLIN_CONSTANT;
                            }
                            // Check max range
                            if (merlinDistance - playerDistance > MAX_RANGE)
                            {
                                Utility.WriteRPG(string.Format("\n({0}) You completly lose sight of Merlin in the depths of the forest!", player.name),
                                    player.textSpeed, 1);
                                detected = true;
                            }
                            // Distance check
                            if (merlinDistance - playerDistance > 200 && detected == false)
                            {
                                Utility.WriteRPG(string.Format("\n({0}) You're starting to lose Merlin in the trees!", player.name),
                                    player.textSpeed, 1);
                            }
                            // Check if you made it
                            if (merlinDistance >= TOTAL_DISTANCE && playerDistance >= TOTAL_DISTANCE)
                            {
                                Utility.WriteRPG(string.Format("\n({0}) You stumbled upon a clearing. In the center of the clearing " + 
                                    "stood a tall, imposing tower, made of grey stone and topped with a pointed spire. The tower was " + 
                                    "surrounded by a tall fence, and ivy crawled up its walls. Its windows were shuttered and barred, " + 
                                    "giving the impression of a fortress. But Merlin is nowhere to be found...", player.name),
                                    player.textSpeed, 1);
                                Console.ReadLine();
                                Utility.WriteRPG(string.Format("\t+Wizard Tower Location\n", player.name),
                                    player.textSpeed, 2);
                                // ADD OPTION TO INVESTIGATE
                                detected = true;
                            }
                            // Player gets too close to Merlin
                            if ((merlinDistance - playerDistance) <= DETECTION_RANGE && merlinDistance < TOTAL_DISTANCE)
                            {
                                Utility.WriteRPG(string.Format("\n({0}) Merlin detected you!", player.name),
                                    player.textSpeed, 1);
                                await Task.Delay(200);
                                Utility.WriteRPG(string.Format("\n[{0}] I thought I told you I needed to be alone?", wizard.name),
                                    player.textSpeed, -1);
                                await Task.Delay(200);
                                Utility.WriteRPG(string.Format("\n({0}) Merlin puts his hands together then instantly vanishes from sight leaving " +
                                    "nothing where he once stood.", player.name),
                                    player.textSpeed, 1);
                                detected = true;
                            }
                        }
                        //
                    }
                }

                // ALONE IN FOREST
                if (true)
                {
                    Utility.WriteRPG(string.Format("\n({0}) You are left alone in the Mystic Woodland Glade...", player.name),
                                    player.textSpeed, 1);
                    Console.ReadLine();
                }

                // TEMP END TO GAME
                if (true)
                {
                    string choice = null;
                    Utility.WriteRPG("\nCURRENT END OF GAME (WIP)\nTHANKS FOR PLAYING!", player.textSpeed, -1);
                    Utility.WriteRPG("\nRestart (R):", player.textSpeed, -1);
                    while (choice == null)
                    {
                        choice = Console.ReadLine();
                    }
                    switch (choice.ToUpper().First())
                    {
                        case 'R':
                            continueGame = true; player = new Player("You", player.textSpeed); break;
                        default:
                            continueGame = false; break;
                    }
                }

            }
            // OUTSIDE GAME WHILE LOOP - This will be ending credits

        }
        // EOF
    }
}
